const express = require('express');
const jwt = require('jsonwebtoken')
require('dotenv').config();
const cookieParser = require('cookie-parser');
const bodyParser = require('body-parser');
const dBase = require('./dataBase');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const path = require('path');
 
const app = express();

app.set('view engine', 'ejs');

app.use(express.static('views'), (req, res, next) =>{
    console.log(req.url);
    next();
});
// app.use(function(req, res, next) {
//     res.setHeader('Access-Control-Allow-Origin', '*');
//     res.setHeader('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content, Accept, Content-Type, Authorization');
//     res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, PATCH, OPTIONS');
//     res.setHeader('Cross-origin-Embedder-Policy', 'require-corp');
//     res.setHeader('Cross-origin-Opener-Policy','same-origin');
//     console.log(req.url);
//     if (req.method === 'OPTIONS') {
//       res.sendStatus(200)
//     } else {
//       next()
//     }
//   });

app.use(cookieParser());

app.use(cors({ origin: process.env.CORS_ORIGIN || '*' }));

// app.use(function(req, res, next) {
//     res.header("Referrer-Policy", "strict-origin");
//     next(); 
// });
 
app.use(helmet());
 
app.use(express.json());

app.use(bodyParser.urlencoded({extended: false}));
 
app.use(morgan('dev'));

app.authenticateToken = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    var token = authHeader && authHeader.split(' ')[1];
    if (token == null) {
        if(req.cookies && req.cookies["AccessToken"])
            token = req.cookies["AccessToken"];
        else
            return res.sendStatus(401);  
    } 
    jwt.verify(token, process.env.ACCESS_TOKEN_SECRET, (err, user) => {
        if(err) return req.sendStatus(403);
        req.user = user
        next();
    });
}

process.on('SIGINT', () => {
    const TAG = '(APP - SIGINT)';
    if (dataBase && dataBase.db) {
        dataBase.db.close((err) => {
            if(err != null)
                console.log(`${TAG} Error on close database: ${err}`);
            process.exit(-1);
        });
        console.log("database closed.");
    }        
    process.exit(0); 

});


const dataBase = new dBase();

dataBase.initDB();
 
module.exports = {app, dataBase};
