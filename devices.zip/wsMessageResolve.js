const moment = require('moment-timezone');
const {app, dataBase} = require('./app');

function onMessage (ws, data, wss){
    const TAG = '(MESSAGERESOLVE - onMessage)';
    console.log(`onMessage: ${data}`);
    try{
        const dados = JSON.parse(data);
        if(dados) {
            if(dados.msg == 'pong') {
                const usr_uid = dados.usr_uid;
                const client_id = dados.client_id;
                const lastPong = Date.now(); //dados.ts;
                if (client_id && ws.atualizaPong !== false) {
                    ws.atualizaPong = true;
                }

                if (lastPong && dataBase.db && ws.atualizaPong == true) {
                    dataBase.setLastPing(client_id, usr_uid, lastPong); // depois de um periodo (longo) será eliminado o dispositivo do banco
                    ws.atualizaPong = false;
                }

                ws.lastPong = lastPong;
                ws.usr_id = usr_uid ? usr_uid : client_id;
                if (!wss.mapCon.has(ws.usr_id)) {
                    wss.mapCon.set(ws.usr_id, ws);
                    if(!client_id) {
                        var tz = moment.tz.zone('America/Sao_Paulo').offset(Date.now());
                        console.log(`Time Zone: ${tz}`);
                        ws.send(JSON.stringify({msg:'SET_TIME', ts: Date.now(), tz_offset: tz}));
                    }
                }
                console.log(`${TAG} Registrado lastPong para usuário: ${usr_uid}, ${client_id}`);
                
            }
            else if (dados.msg == 'DEV_PROPS') { // {msg:'DEV_PROPS', usr_uid:'xxx', tipo:'xxx', nome:'xxx'}
                const usr_uid = dados.usr_uid;
                const dev_name = dados.nome;
                const dev_type = dados.tipo;
                if (usr_uid && dev_name && dev_type) {
                    dataBase.setDeviceProperties(usr_uid, dev_type, dev_name);
                }
                ws.atualizaPong = true;
            }
			else if (dados.msg == 'SEND_STATUS') { // {msg:'SEND_STATUS', client_id=xxx, usr_uid='xxx'}
				const usr_uid = dados.usr_uid;
				const wsx = wss.mapCon.get(usr_uid);
				if (wsx && wsx.readyState === 1){
					wsx.send(JSON.stringify(dados));
				}
			}
            else if (dados.msg == 'DEV_STATUS') {  // {msg:'DEV_STATUS', client_id=xxx, usr_uid='xxx',
                const client_id = dados.client_id; // data:{status:'ON/OFF', ledR:xx, ledG:xx, ledB:xx}} 
				const wsx = wss.mapCon.get(client_id);
				if (wsx && wsx.readyState === 1){
					wsx.send(JSON.stringify(dados));
				}				
            }
            else if (dados.msg == 'CLI_COMANDO') { // {msg:'CLI_COMANDO', client_id=xxx, usr_uid='xxx',
                const usr_uid = dados.usr_uid;     //  data:{status:'ON/OFF', ledR:xx, ledG:xx, ledB:xx}} 
                const wsx = wss.mapCon.get(usr_uid);
                if (wsx && wsx.readyState === 1){
                    wsx.send(JSON.stringify(dados));
                }
            }
            else if (dados.msg == 'CLI_COMANDO_RETORNO') { // {msg:'CLI_COMANDO_RETORNO', client_id=xxx, usr_uid='xxx',
                const client_id = dados.client_id;         //  data:{status:'ON/OFF', ledR:xx, ledG:xx, ledB:xx}} 
                const wsx = wss.mapCon.get(client_id);
                if (wsx && wsx.readyState === 1){
                    wsx.send(JSON.stringify(dados));
                }
            }
        }
    }
    catch(e) {
        console.error(`${TAG} Erro ao analizar/executar mensagem.\n${e.message}`)
    } 
}

module.exports = {
    onMessage
}
