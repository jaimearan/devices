const sqlite3 = require('sqlite3').verbose();

class dataBase {
    constructor () {
        this.db = null;
        this.TAG = 'dataBase';
        this.dbFile = process.env.DB_FILE;
        
    }

    initDB() {
        const TAG = `(${this.TAG} - initDB)`;
        try {
            if (!this.db) {
                this.db = new sqlite3.Database(this.dbFile, sqlite3.OPEN_CREATE | sqlite3.OPEN_READWRITE, (err) => {
                    if(err){
                        console.error("%s Erro ao tentar abrir o banco de dados\n%s", TAG, err)
                    }
                    else {
                        
                    }
                });

            }

            this.db.serialize(() => {  // Roda em sequencia os comandos
        // Tabela de Usuários
                this.db.run("CREATE TABLE IF NOT EXISTS usuarios(  \
                        id INTEGER PRIMARY KEY,     \
                        nome NVARCHAR(80) UNIQUE,   \
                        email NVARCHAR(128),        \
                        senha NVARCHAR(256),        \
                        habil BOOLEAN,              \
                        dataCad DATETIME,           \
                        user_type NVARCHAR(15),     \
                        lastPong DATETIME           \
                    )"
                );
        // Tabela de devices associados a clientes
                this.db.run("CREATE TABLE IF NOT EXISTS device_cliente(  \
                    id INTEGER PRIMARY KEY,     \
                    dev_uid TEXT,               \
                    dev_tipo TEXT,              \
                    client_id INTEGER,          \
                    UNIQUE(dev_uid,client_id)   \
                    )"
                );
                // status => 0 - UNKNOWN, 1- OFF, 2- ON, 
                // dados => json com dados especificos para cada tipo de dispositivo
                // tipo => lampada, tomada, dimmer
                this.db.run("CREATE TABLE IF NOT EXISTS dispositivos( \
                        id INTEGER PRIMARY KEY,     \
                        usr_uid TEXT UNIQUE,               \
                        nome TEXT,                  \
                        nome_ext TEXT,              \
                        local TEXT,                 \
                        tipo TEXT,                  \
                        status TEXT,                \
                        dados TEXT,                 \
                        lastPong DATETIME           \
                    )"
                );

                new Promise((resolve, reject) => {
                    var usrExists = false;
                    this.db.all("SELECT id FROM usuarios where user_type = 'DONO' and habil = true", (err, result) => {
                        if (err) {
                            console.error("%s Erro ao selecionar dados: %s", TAG, err);
                            reject(err)
                        }
                        else {
                            usrExists = result && result.length > 0;
                            resolve(usrExists);
                        }
                    });
                })
                .then((usrExists) => {
                    if(!usrExists) {
                        const stmt = this.db.prepare("INSERT OR IGNORE INTO usuarios VALUES (?,?,?,?,?,?,?,?)");
                        stmt.run(null,'Jaime Aranovich', 'jaime.aranovich@gmail.com', 'crondigo', true, Date.now(), 'DONO', null);
                        stmt.finalize();
                    }
                })
                .catch((err) => {
                    console.error("%s Exceção em SELECT/INSERT: %s", TAG, err)
                })
            });
        }
        catch(e) {
            console.error("%s Exceção: %s", TAG, e)
        }
    }

    getUserByNameAndPassword(nome, senha) {
        const TAG = `(${this.TAG} - getUserByNameAndPassword)`;
        if(!this.db) {
            this.db =  new sqlite3.Database(this.dbFile, sqlite3.OPEN_READ, (err) => {
                if(err){
                    console.error("%s Erro ao tentar abrir o banco de dados\n%s", TAG, err)
                }
            });
        }

        return new Promise((resolve, reject) => {
            this.db.all(`SELECT id, nome, user_type FROM usuarios \
                    where nome = '${nome}' and \
                    senha = '${senha}' and \
                    habil = true`, 
                (err, result) => {
                if (err) {
                    console.error("(%s - Verify user) Erro ao selecionar dados: %s", TAG, err);
                    reject(err);
                }
                else {
                    if (result && result.length > 0) {
                        const row = result[0];
                        const user = {id: row.id , nome: row.nome, user_type: row.user_type};
                        resolve(user);
                    }
                    else
                        resolve(null);
                }
            });
        });
    }

    setLastPing(client_id, usr_uid, ts){
        const TAG = `(${this.TAG} - setLastPing)`
        if (this.db == null) {
            this.db =  new sqlite3.Database(this.dbFile, sqlite3.OPEN_READ, (err) => {
                if(err){
                    console.error("%s Erro ao tentar abrir o banco de dados\n%s", TAG, err)
                }
            });
        }
        this.db.serialize(() => {
            const stmt = usr_uid ? this.db.prepare("Update dispositivos Set lastPong = ? Where usr_uid = ?") :
                                this.db.prepare('Update usuarios Set lastPong = ? Where id = ?');
            stmt.run(ts, (usr_uid? usr_uid : client_id), (result, err) => {
                if (err) {
                    console.error("%s Erro ao atualizar lastPong\n%s", TAG, err);
                }
            });
            stmt.finalize();
        });
    }
    setDeviceProperties(usr_uid, user_type, device_name ) {
        const TAG = `(${this.TAG} - setDeviceProperties)`
        if (this.db == null) {
            this.db =  new sqlite3.Database(this.dbFile, sqlite3.OPEN_READ, (err) => {
                if(err){
                    console.error("%s Erro ao tentar abrir o banco de dados\n%s", TAG, err)
                }
            });
        }
        this.db.serialize(() => {
            const stmt = this.db.prepare("Insert or Ignore into dispositivos(usr_uid, tipo, nome) Values(?,?,?)");
            stmt.run(usr_uid, user_type, device_name, (result, err) => {
                if (err) {
                    console.error("(%s - Get User) Erro ao atualizar dispositivos\n%s", TAG, err);
                }
            });
            stmt.finalize();
        });
    }

    addClientDevRelation(dev_uid, dev_tipo, client_id) {
        const TAG = `(${this.TAG} - addClientDevRelation)`
        if (this.db == null) {
            this.db =  new sqlite3.Database(this.dbFile, sqlite3.OPEN_READ, (err) => {
                if(err){
                    console.error("%s Erro ao tentar abrir o banco de dados\n%s", TAG, err);
                    return false;
                }
            });
        }
        this.db.serialize(() => {
            const stmt = this.db.prepare("Insert or Ignore into device_cliente(dev_uid, dev_tipo, client_id) Values(?,?,?)");
            stmt.run(dev_uid, dev_tipo, client_id, (result, err) => {
                if (err) {
                    console.error("(%s - Get User) Erro ao atualizar device_cliente\n%s", TAG, err);
                    return false;
                }
            });
            stmt.finalize();
            return true;
        });
    }

    getDevicesForClient(client_id) {
        const TAG = `(${this.TAG} - getDevicesForClient)`;
        if(!this.db) {
            this.db =  new sqlite3.Database(this.dbFile, sqlite3.OPEN_READ, (err) => {
                if(err){
                    console.error("%s Erro ao tentar abrir o banco de dados\n%s", TAG, err)
                }
            });
        }

        return new Promise((resolve, reject) => {
            this.db.all(`SELECT d.usr_uid, d.nome, d.tipo from dispositivos d \
                         join device_cliente dc on d.usr_uid = dc.dev_uid \
                         Where dc.client_id = ${client_id} \
                         Order by d.tipo, d.nome`, 
                (err, result) => {
                if (err) {
                    console.error("(%s - DevicesForClient) Erro ao selecionar dados: %s", TAG, err);
                    reject(err);
                }
                else {
                    const rows = [];
                    if (result && result.length > 0) {
                        
                        result.forEach (r => {
                            rows.push({dev_id: r.usr_uid, dev_nome: r.nome, dev_tipo: r.tipo});
                        });

                    }
                    resolve(rows);
                }
            });
        });
    }
}

module.exports = dataBase