const WebSocket = require('ws');
const {app}= require('./app');
const msgResolve = require('./wsMessageResolve');
const jwt = require('jsonwebtoken');


function onError(ws, err) {
    console.error(`onError: ${err.message}`);
}

function broadcast(data, wss) {
    if (!this.clients) return;
    this.clients.forEach(client => {
        if (client.readyState === WebSocket.OPEN) {
            var delta = (Date.now() - client.lastPong) /1000;
            console.log(`Broadcast Delta: ${delta}`);

            if(!(client.atualizaPong === false && delta < 20)) {
                client.send(data);
            }
        }
    });
}

function corsValidation(origin) {
    return process.env.CORS_ORIGIN === '*' || process.env.CORS_ORIGIN.startsWith(origin);
}

function getencodedCookie(encCookies, nome) {
    var cookie = null;
    if (encCookies && encCookies.trim().length > 0) {
        var cookies = decodeURIComponent(encCookies).split(';');
        for(cookie of cookies) {
            var parts = cookie.split('=');
            if(parts.length > 1 && parts[0].trim() == nome) {
                cookie = parts[1].trim();
                break;
            }
        }
    }

    return cookie;
}

function verifyClient(info, callback) {
    try {
        const TAG = '(WebSocket - verifyClient)'
        if (!corsValidation(info.origin)) return callback(false);
        const headers = info.req.headers;

        var token = null
        if (headers["authorization"] != null) {
            token = headers["authorization"].split(' ')[1];
            console.log(token)
        }
        else  {
            token = getencodedCookie(headers.cookie, "AccessToken");
            console.log(token);
        }

        if (token != null)
            return jwt.verify(token, process.env.ACCESS_TOKEN_SECRET, (err, user) => {
                var flg = false;
                if (err) {
                    flg = false;
                    console.error(`${TAG} Acesso não autorizado.`);
                }
                else {
                    console.log(user);
                    flg = true;
                }
                return callback(flg);
            }); 
    }
    catch(err) {
        console.log(`Erro autenticação: ${err}`)
    }
    return callback(false);
}

module.exports = (server) => {
    const wss = new WebSocket.Server({
        server, verifyClient
    });

    wss.on('error', (err) => {
        console.error(`Erro na conexão: ${err}`);
    });

    const mapConnectors = new Map();
    wss.mapCon = mapConnectors;

    wss.on('connection', (ws, req) => {
        ws.on('message', data => msgResolve.onMessage(ws, data.toString(), wss));
        ws.on('error', error => onError(ws, error));
        ws.on('close', ev =>{
            wss.mapCon.delete(ws.usr_id);
        });

        console.log(`onConnection`);
    });


    wss.broadcast = broadcast;
    
    console.log(`App Web Socket Server is running!`);
    return wss;
}