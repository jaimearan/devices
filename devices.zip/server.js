const {app} = require('./app');
const appWs = require('./app-ws');
const jwt = require('jsonwebtoken');
const https = require('https');
const fs = require("fs");
const { encode } = require('punycode');

require('./routes')
 
const _env = process.env

porta = _env.PORT || 4000
// const server = app.listen(porta, "0.0.0.0", () => {
//     console.log(`App Express ativo na porta ${porta}!`);
// });

const servers = https.createServer({
    key: fs.readFileSync("key.pem"),
    cert: fs.readFileSync("cert.pem", encoding='utf-8'),}, app)
.listen(porta, "0.0.0.0", () => {
    console.log('https server is runing at port 4000');
});

const wss = appWs(servers);

var interval = 5000;
setInterval(() => {
    const ping = {msg: "ping", ts: Date.now()}
    const data = JSON.stringify(ping);
    wss.broadcast(data, wss);
}, interval);

