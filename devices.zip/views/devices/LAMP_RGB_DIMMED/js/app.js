var colorPicker = new iro.ColorPicker("#demoWheel", {
  // color picker options
  // Option guide: https://iro.js.org/guide.html#color-picker-options
  width: 270,
  height: 270,
  handleRadius: 8,
  activeHandleRadius: 10,
  handleUrl: null,
  // handleUrl: "#test",
  handleOrigin: {y: 0, x: 0},
  color: "rgb(240, 240, 0)",
  borderWidth: 1,
  borderColor: "#fff",
  padding: 8,
  wheelLightness: true,
  layoutDirection: 'vertical',
  layout: [
    {
      component: iro.ui.Wheel,
      options: {
        wheelDirection: 'clockwise',
        wheelAngle: 0,
      }
    },
    {
      component: iro.ui.Slider,
      options: {
        sliderType: 'value'
      }
    },  ]
});

 colorPicker.on('mount', function() {
   console.log('mount');
   var cor = colorPicker.colors[0];
   console.log("Cor inicial: " + cor.rgbString);
   btn = document.getElementById('on_of');
   setButtonBackColor(btn);
 });

colorPicker.on('input:end', function(color) {
  console.log(color.hexString);
  setButtonBackColor(btn);
  const cor = getrgbcolorarray(color.rgbString);
  ajustSettings(cor);
  settings.status = 'ON';
  deviceSendCmd();
})

function ajustSettings(cor) {
  if(cor.length >= 3) {
    settings.ledR = cor[0];
    settings.ledG = cor[1];
    settings.ledB = cor[2];
  }
}

function deviceSendCmd() {
  const cmd = {msg:'CLI_COMANDO', usr_uid: dev_uid, client_id: client_id, 
               status: settings.status, ledR: Number(settings.ledR),
               ledG: Number(settings.ledG), ledB: Number(settings.ledB)};
  const scmd = JSON.stringify(cmd);
  console.log(scmd);
  if(socket.readyState == WebSocket.OPEN)
    socket.send(scmd);
  else
    console.log("Conexão websocket fechada!")
}


function rgbStringFromSettings() {
  var rgb = 'rgb(';
  rgb += settings.ledR + ',';
  rgb += settings.ledG + ',';
  rgb += settings.ledB + ')';
  return rgb;
}

var btn = null;
var settings = {status:'OFF', ledR:0, ledG:230, ledB: 230};

function setButtonBackColor(btn) {
  const img = btn.firstChild;
  if (settings.status=='ON') {
    img.src = img.src.replace('_off.svg', '_on.svg');
  }
  else {
    img.src = img.src.replace('_on.svg', '_off.svg');
  }
  var cor_arr = getrgbcolorarray(colorPicker.colors[0].rgbString);
  if (settings.status=='OFF') {
    var strrgb = 'rgb(';
    var i = 0;
    for(var cor of cor_arr) {
      var ncor = Math.round(Number(cor)/2, 0);
      strrgb += ncor + (i<2 ? ',' : '');
      i++;
    }
    strrgb += ')';
    btn.style.backgroundColor = strrgb;
  }
  else {
    btn.style.backgroundColor = colorPicker.colors[0].rgbString;
  }
}

var client_id;
var dev_uid;
var socket;
addEventListener('DOMContentLoaded', (event) => {
  const wsserver = document.getElementById('wsserver').value;
  client_id = Number(document.getElementById('client_id').value);
  dev_uid = document.getElementById('usr_uid').value;
  var tim_dev_status = 0;
  var dev_status_recv = false;

  
  btn = document.getElementById('on_of');
  btn.addEventListener('click', function(e) {
    settings.status = (settings.status == 'ON') ? 'OFF' : 'ON';
    setButtonBackColor(btn);
    deviceSendCmd(); 
  });

  try{
    socket = new WebSocket(wsserver);
  }
  catch(e) {
    console.error('Não foi possível criar websocket!')
    return;
  }
  
  socket.onopen = function(e) {
    console.log("[open] Connection established");
    const cmd = { msg:'SEND_STATUS', client_id:client_id, usr_uid:dev_uid };
    console.log(cmd);
    socket.send(JSON.stringify(cmd));
    
    tim_dev_status = setInterval(() =>{
      if (!dev_status_recv) {
        if(socket.readyState == WebSocket.OPEN)
          socket.send(JSON.stringify(cmd));
      }
      else {
        clearInterval(tim_dev_status);
        tim_dev_status = 0;
      }
    }, 5000);

  };

  socket.onmessage = (event) => {
    const dados = JSON.parse(event.data);
    if (dados.msg == 'ping') {
      const pong = { msg:'pong', client_id: client_id, ts:Date.now()};
      const spong = JSON.stringify(pong);
      socket.send(spong);
      console.log(`resposta ao ping: ${spong}`);
    }
    else if (dados.msg == "DEV_STATUS") {
      console.log(dados);
      if (dados.data && dados.data.status && dados.data.ledR >= 0 &&
          dados.data.ledG >= 0 && dados.data.ledB >= 0)
        settings = dados.data;
        colorPicker.color.set(rgbStringFromSettings());
        setButtonBackColor(btn);
        dev_status_recv = true;
        clearInterval(tim_dev_status);
        tim_dev_status = 0;
    }
    else if (dados.msg == "CLI_COMANDO_RETORNO") {
      console.log(dados);
    }
  };
  
  socket.onclose = function(event) {
    if (event.wasClean) {
      console.log(`[close] Connection closed cleanly, code=${event.code} reason=${event.reason}`);
    } else {
      // e.g. server process killed or network down
      // event.code is usually 1006 in this case
      console.log('[close] Connection died');
    }
  };

  const btnRetorna = document.getElementById("btnRetorna");
  btnRetorna.addEventListener('click', function(e) {
    document.cookie = `client_id=${client_id};max-age=20`;
    document.cookie = `wsserver=${wsserver};max-age=20`;
    var url = wsserver.replace("wss://", "https://");
    url = url.replace("ws://", "http://");
    window.location = url;
  });
  
  socket.onerror = function(error) {
    console.log(`[error]`);
  };

});

function getrgbcolorarray(strrgb) {
  var arr = [];
  const regex = /rgb\((\d+),\s*(\d+),\s*(\d+)\)/;
  const found = strrgb.match(regex);
  if(found && found.length >= 4)
    arr = [found[1], found[2], found[3]];
  return arr;
}

function stopSocket() {
  if(socket) {
    socket.close();
  }
  socket = null;
}
