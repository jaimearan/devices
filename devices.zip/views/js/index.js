var setDevStatusCtrls = (elem, status_rede, status_dev) => {
    const devstatus = elem.querySelector('.dev_status');
    const st_text = devstatus.getElementsByTagName('span');
    const st_img = devstatus.getElementsByTagName('img');
    if(st_text && st_text.length > 0) {
        const elem = st_text[0];
        if(elem) {
            elem.textContent = status_rede;
            elem.className = (status_rede == 'offline') ? 'con' : 'coff';
        }
    }
    if(st_img && st_img.length > 0) {
        const elem = st_img[0];
        if(elem) {
            elem.className = (status_rede != 'offline') ? 'con' : 'coff';
            var attr_src = elem.getAttribute('src');
            if (status_dev == 'ON')
                attr_src = attr_src.replace('_off.png', '_on.png');
            else
                attr_src = attr_src.replace('_on.png', '_off.png');
            elem.setAttribute('src', attr_src);
        }   
    }
};

var getDevCtrlByDevId = (dev_ctrls, dev_id) => {
    for (var d of dev_ctrls) {
        if (d.dev_id == dev_id)
            return d;
    }
    return null;
};

var findDevinSettings = (dev_id) => {
    for(var s of settings) {
        if (s.dev_id == dev_id)
            return s;
    }
    return null;
};

function stopSocket() {
    if(socket) {
      socket.close();
    }
    socket = null;
}

var socket = null;
var client_id;
// remover a logica dependente do settings
var settings = [];  // {dev_id: '', data:{status:'ON/OFF'}}
addEventListener('DOMContentLoaded', (docEv) => {
    client_id = Number(document.getElementById('client_id').value);
    const wsserver = document.getElementById('wsserver').value;
    
    const dev_elems = document.getElementsByClassName("dev_corpo");

    const addDeviceBtn = document.getElementsByClassName('dev-header')[0].getElementsByTagName('i')[0];

    socket = new WebSocket(wsserver);

    const dev_ctrls = []; 

    var setControls = (dados) => {
        const dev_id = dados.usr_uid;
        // busca elem no array dev_ctrl, acerta status na página e no array
        const dc = getDevCtrlByDevId(dev_ctrls, dev_id);
        if(dc) {
            if (dados.data && dados.data.status) {
                dados.status = dados.data.status;
            }
            dc.elem.setAttribute('data_rede', 'online');
            dc.offline = false;
            dc.lastime = Date.now();
            var dev = findDevinSettings(dev_id);
            if(!dev) {
                dev = {dev_id: dev_id, status: dados.status};
                settings.push(dev);
            }
            else {
                dev.status = dados.status;
            }
           // acerta controle na pagina;
           setDevStatusCtrls(dc.elem, 'online', dev.status);
        }    
    }

    socket.onopen = function(ev) {
        console.log("[open] Connection established");
        var dly = 0;
        for(var elem of dev_elems) {
            const dev_id = elem.getAttribute("data_devid");
            const cmd = { msg:'SEND_STATUS', client_id:client_id, usr_uid: dev_id};
            console.log(cmd);
            socket.send(JSON.stringify(cmd));
            var lastime = Date.now();
            const dc = {tmout:1000 + dly, elem: elem, dev_id: dev_id, offline: true, lastime: lastime};
            dly += 50;
            dev_ctrls.push(dc);
        }

        var tmrIni = Date.now();
        var tmr_scan = setInterval(() => {
            for(var dev of dev_ctrls) {
                var agora = Date.now();
                if((agora - tmrIni) >= (dev.tmout * (dev.offline ? 1 : 5))) {
                    tmrIni = Date.now();
                    const cmd = { msg:'SEND_STATUS', client_id:client_id, usr_uid: dev.dev_id};
                    if (socket && socket.readyState == WebSocket.OPEN) {
                        socket.send(JSON.stringify(cmd));
                        console.log(cmd);
                    }
                }
                if (!dev.offline && (agora - dev.lastime) >= 7000) {
                    dev.offline = true;
                    dev.lastime = agora;
                    // acerta controle na pagina;
                    setDevStatusCtrls(dev.elem, 'offline', 'OFF');
                }
            };
        }, 100);

    };

    socket.onmessage = (ev) => {
        const dados = JSON.parse(ev.data);
        if (dados.msg == 'ping') {
          const pong = { msg:'pong', client_id: client_id, ts:Date.now()};
          const spong = JSON.stringify(pong);
          socket.send(spong);
          console.log(`resposta ao ping: ${spong}`);
        }
        else if (dados.msg == "DEV_STATUS") {
            console.log(dados);
            if (dados.data, dados.data.status) {
                setControls(dados);
            }
            else {
                console.error("Mensagem DEV_STATUS com erro.");
            }
        }
        else if (dados.msg == "CLI_COMANDO_RETORNO") {
            // Verifica retorno do comando e acerta status do controle e settings
            console.log(dados);
            if (dados && dados.status) {
                setControls(dados);
            }
            else {
                console.error("Mensagem CLI_COMANDO_RETORNO com erro.");
            }       
        } 
          
    };

    socket.onclose = (ev) => {
        if (ev.wasClean) {
            console.log(`[close] Connection closed cleanly, code=${ev.code} reason=${ev.reason}`);
        } else {
          // e.g. server process killed or network down
          // event.code is usually 1006 in this case
          console.log('[close] Connection died');
        }
    };
      
    socket.onerror = (error) => {
        console.log(`Socket error: ${error}`);
    };
    
    // Set click events
    var lock_click = false;
    for(var elem of dev_elems) {

        const dev_id = elem.getAttribute("data_devid");
        elem.addEventListener('click', (e) => {
            if (lock_click) return;
            const status_rede = elem.getAttribute("data_rede");
            if(status_rede == 'online') {
                e.preventDefault();

                document.getElementById("dev_tipo").value = elem.getAttribute("data_devtipo");
                document.getElementById("dev_uid").value = dev_id;
                document.getElementById("frm_devices").submit();
            }
        });

        const devstatus = elem.querySelector('.dev_status');
        devstatus.addEventListener('click', () => {
            lock_click = true;
            setTimeout(() => {
                lock_click = false;
            }, 200);
            const status_rede = elem.getAttribute("data_rede");
            if(status_rede == 'online') {
                // Liga/Desliga o dispositivo
                if(socket.readyState == WebSocket.OPEN) {
                    const dev = findDevinSettings(dev_id);
                    if(dev) {
                        const cmd = {msg: "CLI_COMANDO", client_id: client_id, usr_uid: dev_id, 
                                    status: (dev.status == 'ON') ? 'OFF' : 'ON'};
                        console.log(cmd);
                        socket.send(JSON.stringify(cmd));
                    }
                    else {
                        console.error("Dispositivo desconhecido.");
                    }
                }
            }
        });
          
    }

    addDeviceBtn.addEventListener('click', (ev) => {
        if (window.Android) {
            window.Android.scanDevices();
        }
    });

    function getCookie(name) {
        function escape(s) { return s.replace(/([.*+?\^$(){}|\[\]\/\\])/g, '\\$1'); }
        var match = document.cookie.match(RegExp('(?:^|;\\s*)' + escape(name) + '=([^;]*)'));
        return match ? match[1] : null;
    }

    var cookie = getCookie("Usuario");
    console.log(`Cookie - Usuario: ${cookie}`);
});