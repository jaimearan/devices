addEventListener('DOMContentLoaded', (docEv) => {
    var username = document.getElementById('name').value;
    var userpwd = document.getElementById('senha').value;
    const btnSubmit = document.getElementsByClassName('btn-block')[0].children[1];
    const mgsBox = document.getElementsByClassName('btn-block')[0].children[0];

    const xmlDoc = new XMLHttpRequest();
    if(xmlDoc) {
        //callback for readystate when it returns
        xmlDoc.onreadystatechange = () => {
            if (xmlDoc.readyState === 4 && xmlDoc.status === 200) {
                try {
                    const data = JSON.parse(xmlDoc.responseText);
                    if(!data.error) {
                        const token = data.accessToken;
                        const client_id = data.client_id; 
                        if(window.Android) {
                            window.Android.saveCredentialsAndGo(username, userpwd, client_id, token);
                        }
                        else {
                            mgsBox.innerHTML = "Aplicativo não operacional em browser!";
                        }
                    }
                    else {
                        mgsBox.innerHTML = data.error; 
                    }
                }
                catch(e) {
                    mgsBox.innerHTML = "Erro de sistema! Aplicativo não operacional.";
                }
            }
        }
    }

    btnSubmit.addEventListener("click", (e) => {
        if (e.preventDefault) e.preventDefault();

        username = document.getElementById('name').value;
        userpwd = document.getElementById('senha').value;
    
        //set up the soap xml web service call
        xmlDoc.open("POST", window.location, true);
        xmlDoc.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        xmlDoc.setRequestHeader("username", username);
        xmlDoc.setRequestHeader("userpwd", userpwd);
        xmlDoc.send("");        

        return false;
    });


    if (username && userpwd) {
        btnSubmit.click();
    }


});