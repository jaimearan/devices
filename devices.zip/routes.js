const {app, dataBase} = require('./app');
//const {dataBase} = require('./app');
const jwt = require('jsonwebtoken');
const { Db } = require('mongodb');

const _env = process.env;
// chamada via webservice, 
// resposta com o token 
// salvar em cookie local pelo cliente
app.post('/login', (req, res, next) => {
    // Authenticate User
    const rbd = req.headers;

    // se usuário não existe deve criar usuário
    dataBase.getUserByNameAndPassword(rbd.username, rbd.userpwd)
    .then((user) => {
        if (user) {
            const accessToken = jwt.sign(user, _env.ACCESS_TOKEN_SECRET);
            //60 * 60 * 1000 === 3600,000, or 1 day in milliseconds * 24 hours
            var expiryDate = new Date(Number(new Date()) + 24 * 3600000); 
            res.cookie('Usuario', JSON.stringify(user), { expires: expiryDate, httpOnly: true });
            res.cookie('AccessToken',accessToken, { expires: expiryDate, httpOnly: true });
            res.json({error: null, accessToken: accessToken, client_id: user.id });
        }
        else {
            res.clearCookie('Usuario');
            res.clearCookie('AccessToken');
            res.json({error: "Usuário e senha não combinam.", accessToken: null });
            console.error("(Server - login) usário/senha não confere.");
        }
    })
    .catch((err) => {
        res.clearCookie('Usuario');
        res.clearCookie('AccessToken');
        console.error("(Server - login) Erro acesso usuarios.\n%s", err);
        res.json({error: "Ocorreu um erro interno no servidor.", accessToken: null });
    });
});

app.get('/login',  (req, res, next) => {
    // Authenticate User
    var username = req.headers.ws_usr;
    var userpwd = req.headers.ws_upwd;
    // if(!username || !userpwd) {
    //     username= 'Jaime Aranovich';
    //     userpwd = 'crondigo';
    // }
    
    res.render('login', {userName: username, userPwd: userpwd})
 
});

app.get("/", app.authenticateToken, (req, res, next) => { 
    var client_id = req.headers.client_id;
    var wsserver = req.headers.wsserver;
    if(!client_id || !wsserver) {
        client_id = req.cookies.client_id;
        wsserver = req.cookies.wsserver;
    }     
    if(client_id) {
        dataBase.getDevicesForClient(client_id)
        .then((devs) => {
            var dados = [];
            devs.forEach((dev) => {
                dados.push({
                    tipo_device: dev.dev_tipo, status_rede: 'offline', status_dev: 'off',
                    nome_device: dev.dev_nome, id_device: dev.dev_id, 
                    
                });
            });
            res.header('Content-Type', 'text/html; charset=utf-8');
            res.render('index', {title: 'Automata', cabecalho: 'Dispositivos cadastrados', 
                                 wsserver: wsserver, client_id: client_id, data: dados});
        })
        .catch((err) => {
            res.render('error', {title:'Automata', message:"Erro ao acessar banco de dados", 
                       error:err});
        });
    }
    else {
        res.render('error', {title:'Automata', message:"Dados incompletos - Origem desconhecida", error:{status:'', 
                   stack:'Esta página não pode ser acessada do browser.'}});
    }
});

app.get('/devicesclient', app.authenticateToken, (req, res, next) => { 
    const headers = req.headers;
    const client_id = headers.client_id;
    if(client_id) {
        dataBase.getDevicesForClient(client_id)
        .then((devs) => {
            const result = {error: null, dados: devs};
            res.json(result);
        })
        .catch((err) => {
            const result = {error: err, dados: null};
            res.json(result);
        });
    }
});

app.post('/putdeviceclient', app.authenticateToken, (req, res, next) => {
    const dev_uid = req.headers.dev_uid;
    const dev_tipo = req.headers.dev_tipo;
    const client_id = req.headers.client_id;
    dataBase.addClientDevRelation(dev_uid, dev_tipo, client_id);
    res.json({result:'OK'});
});

app.post('/devices', app.authenticateToken, (req, res, next) => {
    // Authenticated User
    const token = req.cookies["AccessToken"];
/*     var headerData;
    if (!token) {
        headerData = {accesstoken: token, client_id: 1, 
        usr_uid:"00ec62bf-fde8-4a49-b4b5-1d18c550beef",
        wsserver: "wss://192.168.1.135:4000", dev_tipo: "LAMP_RGB_DIMMED"};
    }
    else {
*/     const usuario = JSON.parse(req.cookies["Usuario"]);
        const headerData = {/* accesstoken: token,  */client_id: usuario.id, 
            usr_uid: req.body.dev_uid,
            wsserver: req.body.wsserver, dev_tipo: req.body.dev_tipo};
//    }
    
    res.header("Referer", `/devices`);
    res.render(`devices/${headerData.dev_tipo}/index.ejs`, {data: headerData});
});

